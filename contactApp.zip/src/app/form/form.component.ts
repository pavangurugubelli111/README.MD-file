import {FormserviceService} from '../formservice.service';
import {Form} from '../form';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  toTable!:FormGroup
  login: boolean;
  signindetails: boolean;
  signupdate: boolean;
  addcontact: boolean;
  
  
  constructor(private fb1:FormBuilder) {
    this.toTable=this.fb1.group({
      email:[""],
      password:[""],
      email1:[""],
      number:[""],
      name:[""],
      Secret:[""],
    })
   }

  ngOnInit(): void {
  }
  @Input() childData:any=[]
  @Output()  fromChild=new EventEmitter;
  submitData(){
    console.log(this.toTable.value)
     this.childData.push(this.toTable.value)
   
  }
  save(){
    this.signindetails = true
  }
  signin(){
    this.login = true
    this.addcontact = true
  }
  signup(){
    this.login = true
    this.signupdate = true
    this.addcontact = false
  }
  signupSuccess(){
    this.login = false
    this.signupdate = false 
  }
}
