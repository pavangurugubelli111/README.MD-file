import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-comp-eight',
  templateUrl: './comp-eight.component.html',
  styleUrls: ['./comp-eight.component.scss']
})
export class CompEightComponent implements OnInit {
  tableForm!:FormGroup
  data=([] as any);
  constructor(private fb:FormBuilder) {
    this.tableForm=this.fb.group({
      fullname:[""],
      age:[""],
      address:[""]
    })
   }

  ngOnInit(): void {
  }
  submitData(){
    console.log(this.tableForm.value)
    this.data.push(this.tableForm.value)
  }
  displaydata(event:any){
this.data.push(event)
  }
}
