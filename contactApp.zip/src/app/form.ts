export class Form {
    constructor(public name:string,public Email:string,public Mobile:any,public street:string,public city:string)
    {

    }
}
