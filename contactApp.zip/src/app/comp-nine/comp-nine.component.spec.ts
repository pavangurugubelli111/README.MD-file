import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompNineComponent } from './comp-nine.component';

describe('CompNineComponent', () => {
  let component: CompNineComponent;
  let fixture: ComponentFixture<CompNineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompNineComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompNineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
