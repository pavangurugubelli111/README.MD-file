import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-comp-nine',
  templateUrl: './comp-nine.component.html',
  styleUrls: ['./comp-nine.component.scss']
})
export class CompNineComponent implements OnInit {
  toTable!:FormGroup
  
  
  constructor(private fb1:FormBuilder) {
    this.toTable=this.fb1.group({
      fullname:[""],
      age:[""],
      address:[""]
    })
   }

  ngOnInit(): void {
  }
  @Input() childData:any=[]
  @Output()  fromChild=new EventEmitter;
  submitData(){
    console.log(this.toTable.value)
     this.childData.push(this.toTable.value)
   
  }

}
